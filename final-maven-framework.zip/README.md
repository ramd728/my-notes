# Fullstack Maven Automation Framework

## Tech Stack
- Playwright Java for UI
- RestAssured for API
- TestNG for test management
- Allure for reporting
- JSON & Properties for data/config
- Retry logic, screenshot, trace capture

## Usage
1. `mvn clean test`
2. `allure serve target/allure-results`
