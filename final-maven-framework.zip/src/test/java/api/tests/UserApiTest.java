
package api.tests;

import io.restassured.RestAssured;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UserApiTest {
    @Test(groups = "regression", retryAnalyzer = common.utils.RetryAnalyzer.class)
    public void testUserLoginAPI() {
        RestAssured.baseURI = "https://reqres.in/api";

        given()
            .header("Content-Type", "application/json")
            .body("{ \"email\": \"eve.holt@reqres.in\", \"password\": \"cityslick\" }")
        .when()
            .post("/login")
        .then()
            .statusCode(200)
            .body("token", notNullValue());
    }
}
