
package ui.pages;

import com.microsoft.playwright.Page;

public class LoginPage {
    private Page page;

    public LoginPage(Page page) {
        this.page = page;
    }

    public void login(String username, String password) {
        page.fill("#username", username);
        page.fill("#password", password);
        page.click("#loginBtn");
    }

    public boolean isLoginSuccessful() {
        return page.locator("#logout").isVisible();
    }
}
