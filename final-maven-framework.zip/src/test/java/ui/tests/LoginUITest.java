
package ui.tests;

import com.microsoft.playwright.*;
import org.testng.annotations.*;
import ui.pages.LoginPage;
import static org.testng.Assert.*;

public class LoginUITest {
    private Playwright playwright;
    private Browser browser;
    private Page page;

    @BeforeClass
    public void setup() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true));
        page = browser.newPage();
    }

    @Test(groups = "smoke", retryAnalyzer = common.utils.RetryAnalyzer.class)
    public void verifyLoginSuccess() {
        page.navigate("https://example.com/login");
        LoginPage loginPage = new LoginPage(page);
        loginPage.login("testuser", "testpass");
        page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("reports/ui-login.png")));
        assertTrue(loginPage.isLoginSuccessful());
    }

    @AfterClass
    public void teardown() {
        page.close();
        browser.close();
        playwright.close();
    }
}
