def get_auth_token():
    return "mocked_token"
