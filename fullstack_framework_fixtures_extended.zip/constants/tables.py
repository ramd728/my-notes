DB_TABLE_TEST_CASES = "test_cases"
DB_TABLE_TEST_DATA = "test_data"
DB_TABLE_RESULTS = "test_results"
