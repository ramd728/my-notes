
import psycopg2
import pytest

@pytest.fixture(scope="session")
def db_connection(env_config):
    conn = psycopg2.connect(
        host=env_config["db_host"],
        user=env_config["db_user"],
        password=env_config["db_password"],
        database=env_config["db_name"]
    )
    yield conn
    conn.close()
