
import pytest
import os
from dotenv import load_dotenv

@pytest.fixture(scope="session")
def env_config():
    env = os.getenv("ENV", "dev")
    load_dotenv(dotenv_path=f"config/.env.{env}")
    return {
        "env": env,
        "base_url": os.getenv("BASE_URL"),
        "db_host": os.getenv("DB_HOST"),
        "db_user": os.getenv("DB_USER", "user"),
        "db_password": os.getenv("DB_PASSWORD", "pass"),
        "db_name": os.getenv("DB_NAME", "test_db")
    }
