
import os
import json
import pytest

@pytest.fixture(scope="session", autouse=True)
def store_allure_results_in_db(request, db_connection):
    yield
    results_dir = "allure-results"
    cursor = db_connection.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS test_results (
            uuid TEXT PRIMARY KEY,
            name TEXT,
            status TEXT,
            start_time BIGINT,
            stop_time BIGINT,
            environment TEXT
        );
    """)

    for file in os.listdir(results_dir):
        if file.endswith("-result.json"):
            with open(os.path.join(results_dir, file)) as f:
                result = json.load(f)
                cursor.execute("""
                    INSERT INTO test_results (uuid, name, status, start_time, stop_time, environment)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT (uuid) DO NOTHING;
                """, (
                    result.get("uuid"),
                    result.get("name"),
                    result.get("status"),
                    result.get("start", 0),
                    result.get("stop", 0),
                    os.getenv("ENV", "dev")
                ))
    db_connection.commit()
