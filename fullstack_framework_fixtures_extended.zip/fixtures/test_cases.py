
import pytest

@pytest.fixture(scope="session")
def test_cases(db_connection):
    cursor = db_connection.cursor()
    cursor.execute("SELECT id, name, type FROM test_cases WHERE active = true;")
    return cursor.fetchall()
