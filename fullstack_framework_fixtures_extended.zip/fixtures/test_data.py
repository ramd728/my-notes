
import pytest

@pytest.fixture(scope="session")
def test_data(db_connection):
    cursor = db_connection.cursor()
    cursor.execute("SELECT case_id, data_key, data_value FROM test_data;")
    raw = cursor.fetchall()
    data = {}
    for case_id, key, value in raw:
        data.setdefault(case_id, {})[key] = value
    return data
