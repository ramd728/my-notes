import requests

def get_user(user_id, base_url, token):
    headers = {"Authorization": f"Bearer {token}"}
    return requests.get(f"{base_url}/users/{user_id}", headers=headers)
