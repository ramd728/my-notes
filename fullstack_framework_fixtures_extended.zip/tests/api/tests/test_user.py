import pytest
from tests.api.clients.user_client import get_user
from auth.token import get_auth_token

def test_get_user(env_config):
    token = get_auth_token()
    response = get_user(1, env_config["base_url"], token)
    assert response.status_code == 200
