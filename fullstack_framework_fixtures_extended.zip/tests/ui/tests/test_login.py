import pytest
from tests.ui.pages.login_page import LoginPage

def test_login_success(page):
    login = LoginPage(page)
    login.login("user", "pass")
    assert "Dashboard" in page.title()
