import psycopg2
import os

def get_db_connection():
    return psycopg2.connect(
        host=os.getenv("DB_HOST"),
        database="test_db",
        user="user",
        password="pass"
    )
