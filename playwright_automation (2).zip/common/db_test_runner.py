import psycopg2
from datetime import datetime

def get_pending_test_cases():
    conn = psycopg2.connect("dbname=testdb user=postgres password=secret")
    cur = conn.cursor()
    cur.execute("SELECT test_case_id, title FROM test_cases WHERE is_active = TRUE")
    all_cases = cur.fetchall()
    cur.execute("SELECT test_case_id FROM test_results")
    executed = {row[0] for row in cur.fetchall()}
    cur.close()
    conn.close()
    return [case for case in all_cases if case[0] not in executed]

def save_result(tc_id, status, error_log=""):
    conn = psycopg2.connect("dbname=testdb user=postgres password=secret")
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO test_results (test_case_id, status, error_log, execution_time) "
        "VALUES (%s, %s, %s, %s) ON CONFLICT (test_case_id) DO NOTHING",
        (tc_id, status, error_log, datetime.now())
    )
    conn.commit()
    cur.close()
    conn.close()