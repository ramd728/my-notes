import allure
from common.db_test_runner import get_pending_test_cases, save_result
import traceback

@allure.step("Execute Test Case: {tc_id} - {title}")
def execute_and_log(tc_id, title):
    try:
        # Example placeholder logic simulating test pass/fail
        if "fail" in title.lower():
            raise Exception("Simulated failure")
        allure.attach("Step Log", f"Test {tc_id} executed successfully", allure.attachment_type.TEXT)
        save_result(tc_id, "PASSED")
    except Exception as e:
        error_log = traceback.format_exc()
        allure.attach("Error Log", error_log, allure.attachment_type.TEXT)
        save_result(tc_id, "FAILED", error_log)
        raise

def run_allure_wrapped_tests():
    pending_tests = get_pending_test_cases()
    if not pending_tests:
        print("✅ All test cases executed.")
        return

    for tc_id, title in pending_tests:
        with allure.step(f"Running: {tc_id} - {title}"):
            execute_and_log(tc_id, title)