import pytest

if __name__ == "__main__":
    pytest.main([
        "tests/",
        "--alluredir=reports/allure-results"
    ])