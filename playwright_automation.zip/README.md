# Playwright Python Automation

Supports UI + API testing with environment and data abstraction.

Run with `pytest tests/`