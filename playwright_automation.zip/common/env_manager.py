import os
from config.config_loader import load_config

env = os.getenv("env", "dev")
config = load_config(env)