import time

def retry(func, attempts=3, delay=2):
    for i in range(attempts):
        try:
            return func()
        except Exception as e:
            time.sleep(delay)
            if i == attempts - 1:
                raise e