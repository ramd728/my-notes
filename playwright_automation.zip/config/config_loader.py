import json
import os

def load_config(env='dev'):
    config_path = f"config/{env}.env.json"
    with open(config_path) as f:
        return json.load(f)