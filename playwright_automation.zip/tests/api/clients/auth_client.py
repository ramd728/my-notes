import requests

def login(base_url, username, password):
    return requests.post(f"{base_url}/login", json={"username": username, "password": password})