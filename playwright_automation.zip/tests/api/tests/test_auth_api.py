from tests.api.clients.auth_client import login

def test_login_api():
    res = login("https://reqres.in/api", "eve.holt@reqres.in", "cityslicka")
    assert res.status_code == 200