def validate_token(response):
    assert "token" in response.json()