import pytest
from tests.ui.pages.login_page import LoginPage

def test_login_valid(page):
    page.goto("https://example.com/login")
    login = LoginPage(page)
    login.login("user1", "pass1")
    assert page.locator("#logout").is_visible()