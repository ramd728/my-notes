# Playwright + PostgreSQL + POM Framework

## Features
- Page Object Model for UI abstraction
- Test case and test step management in PostgreSQL
- Dynamic test execution using DB-driven steps
- Scalable and maintainable structure

## Usage
1. Setup PostgreSQL with tables `test_cases` and `test_steps`
2. Populate test case TC_UI_001 with steps
3. Run `pytest tests/`