# 📘 Database Schema for UI + API Test Case Management

This schema supports enterprise-scale test automation with dynamic, database-driven execution using Playwright (Python).

---

## 🧾 `test_cases`
Stores high-level metadata for all UI and API test cases.

- `test_case_id`: Unique identifier for the test (e.g., TC_UI_001)
- `test_type`: UI or API
- `module`: Feature/module name (Login, Profile, etc.)
- `tags`: Optional labels (e.g., regression, smoke)

---

## 🧪 `test_steps`
Stores executable steps linked to each test case.

- `page`: Name of the POM class (e.g., LoginPage)
- `action_type`: Action like `fill`, `click`, `GET`, `POST`, `assert_text`
- `target_element`: CSS selector (UI) or endpoint (API)
- `input_value`: Value to input or request payload
- `expected_output`: Text or status to assert

---

## 📦 `test_data` (Optional)
Reusable data blobs per test case (used for complex API payloads or shared inputs).

- `data_key`: Reference key (e.g., login_payload)
- `data_type`: Format (JSON, TEXT)
- `data_body`: Full raw data (e.g., JSON)

---

## 📈 `test_results`
Execution log for historical results and resume support.

- `execution_time`: Timestamp of execution
- `status`: PASSED / FAILED
- `error_log`: Stacktrace or failure message

---

## 📁 Usage

1. Execute `db_schema.sql` in your PostgreSQL DB.
2. Insert test cases, steps, and optional data.
3. Use `run_ui_test_case(test_case_id)` in Playwright runner.

---

These schemas work seamlessly with:
- Playwright POM + DB Executor
- Allure Reporting Integration
- CLI + Resume-safe automation