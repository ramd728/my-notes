import psycopg2

def fetch_test_steps(test_case_id):
    conn = psycopg2.connect("dbname=testdb user=postgres password=secret")
    cur = conn.cursor()
    cur.execute(
        "SELECT page, action_type, target_element, input_value FROM test_steps WHERE test_case_id = %s ORDER BY step_number",
        (test_case_id,)
    )
    steps = [{"page": row[0], "action_type": row[1], "target_element": row[2], "input_value": row[3]} for row in cur.fetchall()]
    cur.close()
    conn.close()
    return steps