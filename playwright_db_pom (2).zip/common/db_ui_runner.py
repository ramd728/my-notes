from common.db_helper import fetch_test_steps
from common.page_dispatcher import get_page_object

def run_ui_test_case(test_case_id, page):
    steps = fetch_test_steps(test_case_id)
    for step in steps:
        page_obj = get_page_object(step['page'], page)
        action = getattr(page_obj, step['action_type'])
        if step['action_type'] == 'assert_text':
            action(step['target_element'], step['input_value'])
        elif step['input_value']:
            action(step['target_element'], step['input_value'])
        else:
            action(step['target_element'])