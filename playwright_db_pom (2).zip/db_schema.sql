-- Schema for test_cases
CREATE TABLE IF NOT EXISTS test_cases (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50) UNIQUE NOT NULL,
    title TEXT NOT NULL,
    module VARCHAR(100),
    test_type VARCHAR(10) CHECK (test_type IN ('UI', 'API')),
    description TEXT,
    priority VARCHAR(10),
    tags TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Schema for test_steps
CREATE TABLE IF NOT EXISTS test_steps (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50) REFERENCES test_cases(test_case_id) ON DELETE CASCADE,
    step_number INT NOT NULL,
    page VARCHAR(100),
    action_type VARCHAR(50) NOT NULL,
    target_element TEXT,
    input_value TEXT,
    expected_output TEXT
);

-- Schema for optional reusable test data
CREATE TABLE IF NOT EXISTS test_data (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50) REFERENCES test_cases(test_case_id),
    data_type VARCHAR(20) DEFAULT 'JSON',
    data_key VARCHAR(100),
    data_body TEXT
);

-- Schema for test results logging
CREATE TABLE IF NOT EXISTS test_results (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50),
    execution_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20),
    error_log TEXT
);