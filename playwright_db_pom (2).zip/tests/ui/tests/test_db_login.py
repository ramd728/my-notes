import pytest
from playwright.sync_api import sync_playwright
from common.db_ui_runner import run_ui_test_case

def test_run_ui_from_db():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto("https://example.com/login")
        run_ui_test_case("TC_UI_001", page)
        browser.close()