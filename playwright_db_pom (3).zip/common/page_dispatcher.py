from tests.ui.pages.login_page import LoginPage

def get_page_object(page_name, page):
    if page_name == "LoginPage":
        return LoginPage(page)
    raise Exception(f"Page not found: {page_name}")