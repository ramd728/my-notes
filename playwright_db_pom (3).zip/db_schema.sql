-- Schema for test_cases
CREATE TABLE IF NOT EXISTS test_cases (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50) UNIQUE NOT NULL,
    title TEXT NOT NULL,
    module VARCHAR(100),
    test_type VARCHAR(10) CHECK (test_type IN ('UI', 'API')),
    description TEXT,
    priority VARCHAR(10),
    tags TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Schema for test_steps
CREATE TABLE IF NOT EXISTS test_steps (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50) REFERENCES test_cases(test_case_id) ON DELETE CASCADE,
    step_number INT NOT NULL,
    page VARCHAR(100),
    action_type VARCHAR(50) NOT NULL,
    target_element TEXT,
    input_value TEXT,
    expected_output TEXT
);

-- Schema for optional reusable test data
CREATE TABLE IF NOT EXISTS test_data (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50) REFERENCES test_cases(test_case_id),
    data_type VARCHAR(20) DEFAULT 'JSON',
    data_key VARCHAR(100),
    data_body TEXT
);

-- Schema for test results logging
CREATE TABLE IF NOT EXISTS test_results (
    id SERIAL PRIMARY KEY,
    test_case_id VARCHAR(50),
    execution_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20),
    error_log TEXT
);

-- Sample Insert Statements
-- Sample UI Test Case
INSERT INTO test_cases (test_case_id, title, module, test_type, description, priority, tags)
VALUES ('TC_UI_001', 'Valid Login Test', 'Login', 'UI', 'User logs in with valid credentials', 'High', ARRAY['smoke']);

INSERT INTO test_steps (test_case_id, step_number, page, action_type, target_element, input_value, expected_output)
VALUES 
('TC_UI_001', 1, 'LoginPage', 'fill', 'username', 'user1', NULL),
('TC_UI_001', 2, 'LoginPage', 'fill', 'password', 'pass123', NULL),
('TC_UI_001', 3, 'LoginPage', 'click', 'loginBtn', NULL, NULL),
('TC_UI_001', 4, 'LoginPage', 'assert_text', 'message', NULL, 'Login successful');

-- Sample API Test Case
INSERT INTO test_cases (test_case_id, title, module, test_type, description, priority, tags)
VALUES ('TC_API_001', 'Login API returns token', 'UserAPI', 'API', 'Validates login endpoint response', 'Medium', ARRAY['api', 'sanity']);

INSERT INTO test_steps (test_case_id, step_number, page, action_type, target_element, input_value, expected_output)
VALUES 
('TC_API_001', 1, 'UserClient', 'POST', '/login', '{"email": "eve.holt@reqres.in", "password": "cityslicka"}', 'token');