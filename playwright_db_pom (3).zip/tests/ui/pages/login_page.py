class LoginPage:
    def __init__(self, page):
        self.page = page

    def fill(self, element, value):
        selector = self.get_selector(element)
        self.page.fill(selector, value)

    def click(self, element):
        selector = self.get_selector(element)
        self.page.click(selector)

    def assert_text(self, element, expected):
        selector = self.get_selector(element)
        actual = self.page.inner_text(selector)
        assert actual == expected, f"Expected '{expected}', got '{actual}'"

    def get_selector(self, name):
        mapping = {
            "username": "#username",
            "password": "#password",
            "loginBtn": "#loginBtn",
            "message": "#message"
        }
        return mapping.get(name, name)