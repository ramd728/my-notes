
# Pytest Automation Project

## Includes:
- ✅ Unit tests (math)
- ✅ API tests using `requests`
- ✅ Allure reporting
- ✅ UI tests using Playwright

## Setup

1. Install dependencies:

```bash
pip install pytest requests allure-pytest playwright
playwright install
```

2. Run all tests:

```bash
pytest
```

3. View Allure report:

```bash
allure serve allure-results
```

## Folder Structure
- `tests/` — All test modules
- `pytest.ini` — Pytest config


## Additional Features

### ✅ Database Validation
- Uses SQLite in-memory DB for demo.
- Modify `test_db.py` to connect to PostgreSQL or Oracle as needed.

### 🔁 Retry Logic
- `pytest-rerunfailures` plugin used to auto-rerun flaky tests.

### 🔄 Installation of Extras

```bash
pip install pytest-rerunfailures
```

Run with:

```bash
pytest --reruns 2
```


### 🐘 PostgreSQL Database Test Setup

1. Install psycopg2:
```bash
pip install psycopg2
```

2. Update the database connection details in `test_postgres.py`:
```python
conn = psycopg2.connect(
    host="localhost",
    port=5432,
    database="your_database",
    user="your_user",
    password="your_password"
)
```

3. Run the PostgreSQL test:
```bash
pytest tests/test_postgres.py
```

Make sure your PostgreSQL database is accessible during the test run.


### 🗂 JSON-Based Test Data

To run tests with external JSON data:

1. Edit `testdata/addition_tests.json`:
```json
[
  { "input": [2, 3], "expected": 5 },
  { "input": [10, 15], "expected": 25 }
]
```

2. Test file `test_json_data.py` uses this to drive parameterized testing.

Run with:
```bash
pytest tests/test_json_data.py
```


### 🌐 Environment-Based Configuration

This framework supports environment-based URLs and DB credentials using `config.json`.

To run tests against a specific environment:

```bash
ENV=qa pytest
```

- Supported environments: `dev`, `qa`, `prod`
- Controlled via the `ENV` environment variable
- Config file: `config.json`


### 🧾 Storing Allure Results in PostgreSQL

To save Allure test results to a PostgreSQL DB:

1. Ensure `psycopg2` is installed:
```bash
pip install psycopg2
```

2. Run this after executing your tests:
```bash
python test_utils/allure_to_postgres.py
```

3. The script will:
- Parse files from `allure-results/`
- Insert test UUID, name, status, and timestamps into a `test_results` table

Update connection settings as needed inside `env_config` from `config.json`.
