
import json
import os
import psycopg2

def store_allure_results_in_db(allure_results_dir, db_config):
    # Connect to PostgreSQL
    conn = psycopg2.connect(
        host=db_config["host"],
        port=db_config["port"],
        database=db_config["database"],
        user=db_config["user"],
        password=db_config["password"]
    )
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS test_results (
            uuid TEXT PRIMARY KEY,
            name TEXT,
            status TEXT,
            start_time BIGINT,
            stop_time BIGINT
        );
    """)

    # Parse Allure results
    for file in os.listdir(allure_results_dir):
        if file.endswith("-result.json"):
            path = os.path.join(allure_results_dir, file)
            with open(path, 'r') as f:
                data = json.load(f)
                uuid = data.get("uuid")
                name = data.get("name")
                status = data.get("status")
                start = data.get("start", 0)
                stop = data.get("stop", 0)

                cursor.execute("""
                    INSERT INTO test_results (uuid, name, status, start_time, stop_time)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (uuid) DO NOTHING;
                """, (uuid, name, status, start, stop))

    conn.commit()
    cursor.close()
    conn.close()
