
import pytest

@pytest.fixture(scope="session")
def base_url():
    return "https://jsonplaceholder.typicode.com"

import json
import os
import pytest

@pytest.fixture(scope="session")
def env_config():
    env = os.getenv("ENV", "dev")  # Default to dev
    with open("config.json") as f:
        all_config = json.load(f)
    return all_config[env]
