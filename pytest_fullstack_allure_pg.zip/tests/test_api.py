
import requests

def test_get_post(env_config):
    base_url = env_config["base_url"]
    response = requests.get(f"{base_url}/posts/1")
    assert response.status_code == 200 or response.status_code == 404  # Flexible for demo
