
import sqlite3
import pytest

@pytest.fixture(scope="module")
def db_connection():
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)")
    cursor.execute("INSERT INTO users (name) VALUES ('Alice')")
    cursor.execute("INSERT INTO users (name) VALUES ('Bob')")
    conn.commit()
    yield cursor
    conn.close()

def test_user_count(db_connection):
    db_connection.execute("SELECT COUNT(*) FROM users")
    count = db_connection.fetchone()[0]
    assert count == 2
