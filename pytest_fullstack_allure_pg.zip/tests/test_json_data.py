
import json
import pytest

def load_test_data():
    with open("testdata/addition_tests.json") as f:
        return json.load(f)

@pytest.mark.parametrize("test_case", load_test_data())
def test_addition_cases(test_case):
    result = sum(test_case["input"])
    assert result == test_case["expected"]
