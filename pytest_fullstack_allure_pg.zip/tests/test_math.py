
class TestBasic:

    def test_addition(self):
        assert 2 + 3 == 5

    def test_subtraction(self):
        assert 5 - 3 == 2
