
import pytest
import psycopg2

@pytest.fixture(scope="module")
def pg_connection():
    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        database="your_database",
        user="your_user",
        password="your_password"
    )
    cursor = conn.cursor()
    yield cursor
    cursor.close()
    conn.close()

def test_postgres_query(pg_connection):
    pg_connection.execute("SELECT 1;")
    result = pg_connection.fetchone()
    assert result[0] == 1
