
import random
import pytest

@pytest.mark.flaky(reruns=2)
def test_flaky():
    assert random.choice([True, False])
