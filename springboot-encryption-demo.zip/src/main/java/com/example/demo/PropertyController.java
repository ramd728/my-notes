package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/properties")
public class PropertyController {

    private final PropertyService propertyService;

    public PropertyController(PropertyService propertyService) {
        this.propertyService = propertyService;
    }

    @PostMapping("/save")
    public ResponseEntity<String> saveProperty(@RequestParam String name,
                                               @RequestParam String value,
                                               @RequestParam boolean isSensitive) {
        try {
            propertyService.saveProperty(name, value, isSensitive);
            return ResponseEntity.ok("Saved");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/get")
    public ResponseEntity<String> getProperty(@RequestParam String name) {
        try {
            String value = propertyService.getProperty(name);
            return ResponseEntity.ok(value);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error: " + e.getMessage());
        }
    }
}