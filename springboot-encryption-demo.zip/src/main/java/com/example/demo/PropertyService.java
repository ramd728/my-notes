package com.example.demo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class PropertyService {

    private final JdbcTemplate jdbcTemplate;

    public PropertyService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void saveProperty(String name, String value, boolean isSensitive) throws Exception {
        String encryptedValue = isSensitive ? EncryptionUtil.encrypt(value) : value;
        jdbcTemplate.update("INSERT INTO properties (property_name, property_value, is_sensitive) VALUES (?, ?, ?)", 
                            name, encryptedValue, isSensitive ? "Y" : "N");
    }

    public String getProperty(String name) throws Exception {
        return jdbcTemplate.queryForObject(
            "SELECT property_value, is_sensitive FROM properties WHERE property_name = ?",
            (rs, rowNum) -> {
                String value = rs.getString("property_value");
                boolean isSensitive = "Y".equals(rs.getString("is_sensitive"));
                return isSensitive ? EncryptionUtil.decrypt(value) : value;
            }, name);
    }
}