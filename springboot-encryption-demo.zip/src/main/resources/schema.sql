CREATE TABLE properties (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    property_name VARCHAR(255),
    property_value VARCHAR(4000),
    is_sensitive CHAR(1)
);